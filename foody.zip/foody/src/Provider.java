package bean;  
  
public interface Provider {  
String DRIVER="com.mysql.jdbc.Driver";  
String CONNECTION_URL="jdbc:mysql://localhost/new_schema";  
String USERNAME="root";  
String PASSWORD="root";  
  
}  